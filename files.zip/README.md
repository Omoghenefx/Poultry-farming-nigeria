# Agro Income Nigeria

A professional sales website for the Poultry Farming Blueprint ebook.

## Project Structure

- `package.json` - Project dependencies and scripts
- `pages/index.js` - Main website component
- `next.config.js` - Next.js configuration
- `.gitignore` - Git ignore file

## How to Deploy to Vercel

### Step 1: Create GitHub Repository

1. Go to **github.com** and sign in
2. Click the **"+"** icon → **"New repository"**
3. Name it: `agro-income-nigeria`
4. Choose **Public**
5. Click **"Create repository"**

### Step 2: Upload All Files to GitHub

1. Click **"Add file"** → **"Upload files"**
2. Select ALL these files:
   - `package.json`
   - `pages/index.js`
   - `next.config.js`
   - `.gitignore`
   - `README.md`
3. Click **"Commit changes"**

### Step 3: Deploy on Vercel

1. Go to **vercel.com** and sign in
2. Click **"Add New..."** → **"Project"**
3. Click **"Import from Git"**
4. Select your GitHub repository
5. Click **"Deploy"**
6. Wait 30-60 seconds... Done! ✅

Your site will be live at: `agro-income-nigeria.vercel.app`

## Local Development (Optional)

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm build

# Start production server
npm start
```

Visit `http://localhost:3000` to see your site locally.

## Features

- ✅ Mobile responsive
- ✅ Fast loading
- ✅ SEO optimized
- ✅ Direct Selar integration
- ✅ Email signup form
- ✅ Testimonials & FAQ sections

## Support

For help: support@agro.ng
